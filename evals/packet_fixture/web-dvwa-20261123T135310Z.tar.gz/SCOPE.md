# Authorised scope (2026-11-23). One entry per line: app.example.com (that host), *.example.com
# (its subdomains), host:443,8443 (those ports), 10.0.0.0/24, https://app.example.com/api/ (only that
# path, through the request tool), !admin.example.com (excluded), /src/<repo>.
# Change it here, then run: ./rvkit scope bench-web-dvwa   (./rvkit policy bench-web-dvwa shows what it allows)
- 10.250.0.11
