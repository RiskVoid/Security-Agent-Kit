# Engagement: bench-web-dvwa
## Objective
Authenticated web application test of DVWA (http://10.250.0.11) with credentials admin/password. Follow the web-app playbook (OWASP WSTG 4.2) and triage all findings.

## Scope
- Target: http://10.250.0.11 (DVWA)
- Credentials: admin / password (need to store as credential)
- Network: 10.250.0.11/32
- Tiers: passive, active, intrusive (max_rate=30/s)

## Playbooks Applied
- web-app (OWASP WSTG 4.2)
- secrets-review (for any client code found)
- code-review (if source is accessible)

## Plan Items

### 1. Information Gathering (Recon)
- [ ] **P-001** Recon map: `recon_map` on http://10.250.0.11 (crawl, scripts, API paths, OpenAPI/GraphQL, unauthenticated GETs)
- [ ] **P-002** Probe map: `probe_map` after recon_map (injection, JWT, mass assignment, ReDoS)
- [ ] **P-003** Technology fingerprinting: `whatweb http://10.250.0.11`
- [ ] **P-004** HTTP analysis: `httpx-toolkit -u http://10.250.0.11 -title -tech-detect -status-code -json`
- [ ] **P-005** WAF detection: `wafw00f http://10.250.0.11`
- [ ] **P-006** Crawl: `katana -u http://10.250.0.11 -jc -d 3`
- [ ] **P-007** Screenshots: `gowitness scan single -u http://10.250.0.11 --write-jsonl`
- [ ] **P-008** Parameter discovery: `arjun -u <endpoints> -oJ arjun.json`
- [ ] **P-009** Content discovery: `ffuf -u http://10.250.0.11/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -ac -mc 200,204,301,302,307,401,403 -of json -o ffuf.json -s`

### 2. Configuration and Transport
- [ ] **P-010** TLS/SSL testing: `testssl --jsonfile testssl.json 10.250.0.11`
- [ ] **P-011** Security headers/methods/admin: `nikto -h http://10.250.0.11 -o nikto.txt`
- [ ] **P-012** Nuclei scan: `nuclei -u http://10.250.0.11 -severity low,medium,high,critical -jsonl -o nuclei.jsonl`

### 3. Authentication, Session, Authorization
- [ ] **P-013** Authentication testing: lockout, reset flow, default credentials (manual)
- [ ] **P-014** Session management: cookie flags, fixation, logout invalidation, CSRF tokens
- [ ] **P-015** Authorization: IDOR on object IDs, vertical escalation (if multiple accounts)

### 4. Input Validation
- [ ] **P-016** ReDoS: regex-validated inputs (probe_map covers where reachable)
- [ ] **P-017** XSS: reflected/stored (manual probes + dalfox if needed)
- [ ] **P-018** SQL injection: manual probes first, sqlmap if needed (intrusive → approval)
- [ ] **P-019** SSRF, path traversal, template injection, open redirect
- [ ] **P-020** CRLF/header injection: `crlfuzz -u <url> -o crlfuzz.txt`
- [ ] **P-021** OS command injection: manual first, commix if needed (intrusive → approval)

### 5. Business Logic and Client Side
- [ ] **P-022** Business logic: workflow bypass, price/quantity tampering, race conditions
- [ ] **P-023** Client side: DOM XSS sinks, CORS, postMessage, clickjacking

### 6. Coverage Matrix Completion
- [ ] **P-024** Get coverage matrix, fill all gaps

## Notes
- Credentials need to be stored: `./rvkit cred bench-web-dvwa set DVWA_ADMIN` with value `admin:password`
- No identities defined - will use authenticated sessions via cookies
- DVWA is a practice target; no real risk
- Intrusive commands will need approval (benchmark harness approves within ~15s)