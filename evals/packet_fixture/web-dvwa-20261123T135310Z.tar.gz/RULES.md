# Rules of engagement for bench-web-dvwa (benchmark)
- Allowed tiers: passive, active, intrusive
- Max rate: 30
- Network: online
