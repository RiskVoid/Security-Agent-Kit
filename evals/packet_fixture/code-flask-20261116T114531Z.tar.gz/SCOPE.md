# Authorised scope (2026-11-16). One entry per line: app.example.com (that host), *.example.com
# (its subdomains), host:443,8443 (those ports), 10.0.0.0/24, https://app.example.com/api/ (only that
# path, through the request tool), !admin.example.com (excluded), /src/<repo>.
# Change it here, then run: ./rvkit scope bench-code-flask   (./rvkit policy bench-code-flask shows what it allows)
- /src/rv-bench/rv-demo-app
