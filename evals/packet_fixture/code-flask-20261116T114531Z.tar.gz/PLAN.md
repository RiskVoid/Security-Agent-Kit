# PLAN — bench-code-flask: source review of /src/rv-bench/rv-demo-app

## Objective
Full passive source-code security review of the Flask service at /src/rv-bench/rv-demo-app,
covering its code, secrets and dependencies. Passive tier only (no runtime targets in scope).
The app is a deliberately insecure benchmark fixture (per README and app.py docstring).

## Unattended-run decisions (noted per instructions, no human available)
- Tiers allowed: passive only. No intrusive tools, no runtime testing — the scope is the source tree only.
- Trufflehog run with `--no-verification` (verification would call providers = active/intrusive; not allowed).
- No `.git` directory exists → gitleaks history scan not applicable (recorded as P-020 not-applicable).
- Playbooks applied: code-review, secrets-review, supply-chain. web-app/api-security playbooks are runtime
  playbooks; their code-level equivalents are covered by the code-review checklist items below.
- ASVS level 2 (default). All verification by source review (method=source-review) or scanner output
  (method=tool-output) — no runtime reproduction is possible in a code-only passive engagement.
- All automated scans were delegated to one worker (cost-efficient; a single 28-line file).
- The XSS check (P-019) was added after the initial plan: the code-review playbook's V1 encoding area
  covers output encoding, which the initial plan had folded into data-exposure.

## Attack surface (orientation)
Single-file Flask app (app.py, 28 lines), no auth layer, no template rendering, no file upload.
SQLite database `app.db` (file not present in repo). Entry points:

| Route | Method | Input | Sink | Vulnerability classes |
|---|---|---|---|---|
| /user | GET | `name` query param | `db.execute()` string concat | SQL injection (CWE-89), data exposure, XSS |
| /ping | GET | `host` query param | `subprocess.check_output(shell=True)` | OS command injection (CWE-78) |
| /config | POST | request body | `yaml.load(Loader=yaml.Loader)` | unsafe deserialization → RCE (CWE-502), XSS |
| (app startup) | — | — | `app.run(debug=True, host="0.0.0.0")` | debug RCE/Werkzeug console, CWE-489 |

Config: `SECRET_KEY` hard-coded. Dependencies: flask 0.12.2, PyYAML 5.3, requests 2.19.0
(archaic, multiple known CVEs). No lock file, no CI, no Dockerfile, no .env, no .git.
`requests` is declared but never imported (reachability verdict: unreachable).

## Checklist (from playbooks) — all items have an outcome
- [x] P-001 Inventory/attack surface — tested
- [x] P-002 semgrep (p/python + p/owasp-top-ten) — tested, 7 findings
- [x] P-003 bandit — tested, 7 findings
- [x] P-004 gitleaks dir scan — tested, no leaks
- [x] P-005 trufflehog (no-verification) + trivy fs secret — tested, no leaks
- [x] P-006 syft SBOM + osv-scanner — tested
- [x] P-007 grype on SBOM + pip-audit — tested (49 vulns / 5 packages)
- [x] P-008 SQL injection /user — FAILED → F-001 (high, confirmed)
- [x] P-009 Command injection /ping — FAILED → F-002 (critical, confirmed)
- [x] P-010 YAML deserialization /config — FAILED → F-003 (critical, confirmed)
- [x] P-011 Hard-coded SECRET_KEY — FAILED → F-005 (high, confirmed)
- [x] P-012 Debug mode + 0.0.0.0 bind — FAILED → F-004 (high, confirmed)
- [x] P-013 Auth/authz on routes — FAILED → F-006 (high, confirmed)
- [x] P-014 Security headers/CSP/cookies — FAILED → F-012 (low, confirmed)
- [x] P-015 Data exposure (SELECT *, verbose errors) — FAILED → F-007 (medium, confirmed)
- [x] P-016 Dependency reachability verdicts — FAILED → F-008/F-009/F-010 (confirmed)
- [x] P-017 Supply-chain hygiene — FAILED → F-013 (low, confirmed)
- [x] P-018 Security logging — FAILED → F-014 (low, confirmed)
- [x] P-019 Output encoding / reflected XSS — FAILED → F-011 (medium, confirmed)
- [x] P-020 gitleaks history scan — not-applicable (no .git directory)

## Findings (all confirmed, one per root cause)
| ID | Title | Severity | Priority | CWE |
|---|---|---|---|---|
| F-002 | OS command injection in /ping (shell=True) | Critical | P1 | CWE-78 |
| F-003 | Unsafe YAML deserialization in /config → RCE | Critical | P1 | CWE-502 |
| F-001 | SQL injection in /user | High | P1 | CWE-89 |
| F-004 | Flask debug=True on 0.0.0.0 (Werkzeug console) | High | P1 | CWE-489 |
| F-005 | Hard-coded Flask SECRET_KEY | High | P1 | CWE-798 |
| F-006 | No authentication/authorization on any route | High | P1 | CWE-306 |
| F-008 | PyYAML 5.3 (CVE-2020-1747, CVE-2020-14343) reachable | High | P2 | CWE-1104 |
| F-007 | Full user-row disclosure from /user | Medium | P2 | CWE-200 |
| F-011 | Reflected XSS via unencoded str() output | Medium | P2 | CWE-79 |
| F-009 | Flask 0.12.2 (4 CVEs, EOL) | Medium | P3 | CWE-1104 |
| F-010 | requests 2.19.0 + transitive idna/urllib3 (unused) | Low | P4 | CWE-1104 |
| F-012 | No HTTP security headers or cookie flags | Low | P3 | CWE-693 |
| F-013 | Supply-chain hygiene: no lock file, no CI scanning | Low | P3 | CWE-1104 |
| F-014 | No security logging or error handling | Low | P3 | CWE-778 |

Top three risks for the executive summary: (1) unauthenticated RCE via the /config YAML
deserialization and /ping command injection, compounded by the exposed Werkzeug debugger;
(2) total absence of an auth boundary — every dangerous sink is internet-reachable; (3) the
nine-years-stale dependency set whose PyYAML criticals sit directly on the reachable /config path.

## Verification approach
All findings verified by source review (passive tier; method=source-review) with tool output as supporting
evidence. One finding per root cause. Scanner observations imported and triaged: 38 linked to the
findings above, 1 dismissed (bandit B404 bare-subprocess-import — the real sink is F-002).
No candidate findings remain untriaged. No runtime testing was possible or attempted (code-only scope).
