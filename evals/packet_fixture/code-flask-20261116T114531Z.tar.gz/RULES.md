# Rules of engagement for bench-code-flask (benchmark)
- Allowed tiers: passive
- Max rate: 50
- Network: online
